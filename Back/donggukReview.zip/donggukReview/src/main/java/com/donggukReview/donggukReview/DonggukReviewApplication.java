package com.donggukReview.donggukReview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DonggukReviewApplication {

	public static void main(String[] args) {
		SpringApplication.run(DonggukReviewApplication.class, args);
	}

}
