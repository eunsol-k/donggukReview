package com.donggukReview.donggukReview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DonggukReviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
